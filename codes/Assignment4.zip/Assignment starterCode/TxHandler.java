public class TxHandler {

	public static final int VALID=1;
	public static final int INVALID=-1;
	public static final int POT_VALID=0;
	
    private UTXOPool up;
	
    /**
     * Creates a public ledger whose current UTXOPool (collection of unspent transaction outputs) is
     * {@code utxoPool}. This should make a copy of utxoPool by using the UTXOPool(UTXOPool uPool)
     * constructor.
     */
    public TxHandler(UTXOPool utxoPool) {
        // IMPLEMENT THIS
	    up = new UTXOPool(utxoPool);
    }

    /**
     * @return true if:
     * (1) all outputs claimed by {@code tx} are in the current UTXO pool, 
     * (2) the signatures on each input of {@code tx} are valid, 
     * (3) no UTXO is claimed multiple times by {@code tx},
     * (4) all of {@code tx}s output values are non-negative, and
     * (5) the sum of {@code tx}s input values is greater than or equal to the sum of its output
     *     values; and false otherwise.
     */
    public boolean isValidTx(Transaction tx) {
        // IMPLEMENT THIS
		ArrayList<UTXO> seenUTXO = new ArrayList<UTXO>();
		
		double inSum = 0;
		double outSum = 0;
		
		int index = 0;

		for (Transaction.Input in : tx.getInputs()) {
			
			//Pool to check
			UTXO checkUTXO = new UTXO(in.prevTxHash, in.outputIndex);
			
			//Step 3 no UTXO is claimed multiple times by tx
			if (seenUTXO.contains(checkUTXO)) {
				return false;
			
			seenUTXO.add(checkUTXO);
			
			//step 1 if the transaction pool doesn't contain it already
			if (!up.contains(checkUTXO)) {
				return false;
			}
			
			inSum += up.getTxOutput(checkUTXO).value;
			
			//Step 2 Verify Signature
			if (!up.getTxOutput(checkUTXO).address.verifySignature(tx.getRawDataToSign(index), in.signature))
			{
				return false;
			}
			
			index++;
		}
		
		// Step 4 check output is not negative
		for (Transaction.Output out : tx.getOutputs()) {
			if (out.value < 0) {
				return false;
			}
			outSum += out.value;
		}
		
		// 5 sum of Input must be greater or equal to sum of output
        if(outSum >= inSum)
        {
            return false;
        }

        return true;
    }

    /**
     * Handles each epoch by receiving an unordered array of proposed transactions, checking each
     * transaction for correctness, returning a mutually valid array of accepted transactions, and
     * updating the current UTXO pool as appropriate.
     */
    public Transaction[] handleTxs(Transaction[] possibleTxs) {
        // IMPLEMENT THIS
		
		ArrayList<Transaction> goodTx = new ArrayList<Transaction>();
			
			for(Transaction trans: possibleTxs)
			{
				// Tx is not null
				if (trans == null){
					continue;
				}
				
				// Validate each Tx
				if (isValidTx(trans)) {
					
					// Remove old UTXOs from Pool
					for (trans.Input in : trans.getInputs()) {
						UTXO delUTXO = new UTXO(in.prevTxHash, in.outputIndex);
						up.removeUTXO(delUTXO);
					}
					
					// Add new UTXOs to Pool
					for(int j = 0; j < trans.getOutputs().size(); j++) {
						UTXO newUTXO = new UTXO(trans.getHash(), j);
						up.addUTXO(newUTXO, trans.getOutputs().get(j));
					}
					
					goodTx.add(trans);
				}
			}
			
		}
		
		Transaction[] tArr = new Transaction[goodTx.size()];
		tArr = goodTx.toArray(tArr);
		return tArr;
    }

}
